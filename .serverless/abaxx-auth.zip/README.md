# abaxx-auth
This is where an Abaxx Token is linked to a UserID. 
